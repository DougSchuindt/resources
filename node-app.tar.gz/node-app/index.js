//Documentacao oficial: https://prometheus.io/docs/instrumenting/clientlibs/

var express = require('express');
//importacao da lib do Prometheus
var promClient = require('prom-client');
const register = promClient.register;
var app = express();


//importacao do Counter de acordo com a documentacao oficial do Prometheus
const counter = new promClient.Counter({
  name: 'exemplo_requests',
  help: 'contador de requests',
  labelNames: ['statusCode'],
});

//importacao do Gauge de acordo com a documentacao oficial do Prometheus
const gauge = new promClient.Gauge({
  name: 'exemplo_gauge',
  help: 'contador gauge'
});

//importacao do Histogram de acordo com a documentacao oficial do Prometheus
const histogram = new promClient.Histogram({
	name: 'exemplo_histogram',
  help: 'tempo de resposta da API',
	buckets: [0.1, 0.2, 0.3, 0.4, 0.5]
});

//importacao do Summary de acordo com a documentacao oficial do Prometheus
const summary = new promClient.Summary({
  name: 'exemplo_summary',
  help: 'tempo de resposta da API em %',
  percentiles: [0.5, 0.9, 0.99],
});


app.get('/', function (req, res) {
	counter.labels('200').inc();
	counter.labels('300').inc();
	gauge.set(100 * Math.random());
	const tempo = Math.random();
	histogram.observe(tempo);
	summary.observe(tempo);

	res.send('Hello World!');
});


//endpoint para coleta de metricas pelo Prometheus
app.get('/metrics', async function(req, res) {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
})


app.listen(3001);


//para rodar:
// node index.js
